class ReadonlyProjectError < StandardError
end

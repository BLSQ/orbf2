Rails.application.configure do
  # Settings specified here will take precedence over those in config/application.rb.

  # In the development environment your application's code is reloaded on
  # every request. This slows down response time but is perfect for development
  # since you don't have to restart the web server when you make code changes.
  config.cache_classes = false

  # Do not eager load code on boot.
  config.eager_load = false

  # Show full error reports.
  config.consider_all_requests_local = true

  # Enable/disable caching. By default caching is disabled.
  if Rails.root.join("tmp/caching-dev.txt").exist?
    config.action_controller.perform_caching = true

    config.cache_store = :memory_store
    config.public_file_server.headers = {
      "Cache-Control" => "public, max-age=172800"
    }
  else
    config.action_controller.perform_caching = false

    config.cache_store = :null_store
  end

  # Store uploaded files on the local file system (see config/storage.yml for options)
  config.active_storage.service = ENV.fetch("RAILS_ACTIVE_STORAGE", 'amazon')

  # Don't care if the mailer can't send.
  config.action_mailer.raise_delivery_errors = false

  config.action_mailer.perform_caching = false

  # Print deprecation notices to the Rails logger.
  config.active_support.deprecation = :log

  # Raise an error on page load if there are pending migrations.
  config.active_record.migration_error = :page_load

  # Highlight code that triggered database queries in logs.
  config.active_record.verbose_query_logs = true

  # Debug mode disables concatenation and preprocessing of assets.
  # This option may cause significant delays in view rendering with a large
  # number of complex assets.
  config.assets.debug = true

  # Suppress logger output for asset requests.
  config.assets.quiet = true

  # Raises error for missing translations
  # config.action_view.raise_on_missing_translations = true

  # Use an evented file watcher to asynchronously detect changes in source code,
  # routes, locales, etc. This feature depends on the listen gem.
  config.file_watcher = ActiveSupport::EventedFileUpdateChecker

  config.action_mailer.default_url_options   = { host: "localhost", port: 3000 }
  config.action_mailer.delivery_method       = :smtp
  config.action_mailer.smtp_settings         = { address: "localhost", port: 1025 }

  ::Rack::MiniProfiler.profile_method(Orbf::RulesEngine::Dhis2ValuesPrinter, :print)
  ::Rack::MiniProfiler.profile_method(Orbf::RulesEngine::Solver, :solve!)
  ::Rack::MiniProfiler.profile_method(Orbf::RulesEngine::FetchAndSolve, :call)
  ::Rack::MiniProfiler.profile_method(Orbf::RulesEngine::GroupOrgunitsResolver, :call)
  ::Rack::MiniProfiler.profile_method(Orbf::RulesEngine::ResolveArguments, :call)
  ::Rack::MiniProfiler.profile_singleton_method(Orbf::RulesEngine::ActivityVariablesBuilder, :to_variables)
  #::Rack::MiniProfiler.profile_singleton_method(Orbf::RulesEngine::PeriodIterator, :periods)
  ::Rack::MiniProfiler.profile_method(Orbf::RulesEngine::SolverFactory, :new_solver)

  ::Rack::MiniProfiler.profile_method(Orbf::RulesEngine::DecisionVariablesBuilder, :to_variables)
  ::Rack::MiniProfiler.profile_method(Orbf::RulesEngine::ActivityConstantVariablesBuilder, :to_variables)
  ::Rack::MiniProfiler.profile_method(Orbf::RulesEngine::ActivityFormulaVariablesBuilder, :to_variables)
  ::Rack::MiniProfiler.profile_method(Orbf::RulesEngine::PackageVariablesBuilder, :to_variables)
  ::Rack::MiniProfiler.profile_method(Orbf::RulesEngine::ZoneFormulaVariablesBuilder, :to_variables)
  ::Rack::MiniProfiler.profile_method(Orbf::RulesEngine::PaymentFormulaVariablesBuilder, :to_variables)
  ::Rack::MiniProfiler.profile_method(ActionView::Template, :render)

  ::Rack::MiniProfiler.profile_method(Hesabu::Solver, :solve!)
  ::Rack::MiniProfiler.profile_method(Invoicing::InvoiceEntity, :call)
end
